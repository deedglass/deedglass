Deedglass deed bundle

17 deeds sealed by https://api.deedglass.example
org org_01m3xxf0m2ekmm72j2vvks65q5 · seq 1 to 17
2026-10-02

What is inside
  deeds.jsonl          one sealed deed per line, in seq order
  keys.json            the seal keys that sealed them
  manifest.json        counts, file hashes and the chain head
  manifest.seal.json   the exporter's seal over manifest.json

Check it (no account, no network except fetching the keys)
  deedglass verify <this file> \
    --keys https://api.deedglass.example/.well-known/deedglass/keys.json

What a deed records
  Which agent acted, for whom, what tool ran, which policy decided,
  and what the Witness saw. Payloads are not included, only digests.

What it does not show
  Whether an action was wise. Keys inside this bundle come from the
  exporter; pin the issuer's published keys for authenticity.

Spec: https://docs.deedglass.com/deeds/spec
